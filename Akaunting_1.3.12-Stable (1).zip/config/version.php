<?php

return [

    'name'      =>  'Akaunting',

    'code'      =>  'Reconciliation',

    'major'     =>  '1',

    'minor'     =>  '3',

    'patch'     =>  '12',

    'build'     =>  '',

    'status'    =>  'Stable',

    'date'      =>  '13-February-2019',

    'time'      =>  '17:00',

    'zone'      =>  'GMT +3',

];
